public class Looptest{
    public static void main(String[]args){
        for(i=1;i<1001;i++){}
    }
}