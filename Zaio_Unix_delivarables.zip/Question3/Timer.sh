#!/bin/bash

java Loop.java



time java Loop